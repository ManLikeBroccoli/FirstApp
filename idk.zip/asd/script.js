<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productivity App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #4CAF50;
        }
        #calorieCounter, #worldClock {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            max-width: 400px;
        }
        input {
            width: calc(100% - 20px);
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            margin-top: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #45a049;
        }
        p {
            margin: 5px 0;
        }
    </style>
</head>
<body>

    <h1>All-in-One Productivity App</h1>

    <!-- Calorie Counter Section -->
    <div id="calorieCounter">
        <h2>Calorie Counter</h2>
        <input type="text" id="food" placeholder="Enter food name">
        <button onclick="searchCalories()">Search Calories</button>
        <p id="caloriesDisplay"></p>
    </div>

    <!-- World Clock Section -->
    <div id="worldClock">
        <h2>World Clock</h2>
        <div id="worldClockDisplay"></div>
    </div>

    <script>
        // Food Data: Array of objects with food items and their average calorie counts
        const foodData = [
            { name: 'Banana', calories: 89 },
            { name: 'Apple', calories: 95 },
            { name: 'Chicken Burger (1 Pattie)', calories: 250 },
            { name: 'Beef Burger', calories: 354 },
            { name: 'Rice (1 cup)', calories: 206 },
            { name: 'Pasta (1 cup)', calories: 221 },
            { name: 'Pizza Slice (Cheese)', calories: 285 },
            { name: 'Egg (boiled)', calories: 78 },
            { name: 'Milk (1 glass)', calories: 149 },
            { name: 'Orange', calories: 62 },
            { name: 'Salad (vegetable)', calories: 33 },
            { name: 'Peanut Butter (1 tbsp)', calories: 94 },
            { name: 'Almonds (10)', calories: 70 },
            { name: 'French Fries (medium)', calories: 365 },
            { name: 'Chicken Wings (fried, 3 pcs)', calories: 250 },
            { name: 'Steak (8 oz)', calories: 600 },
            { name: 'Chocolate Bar', calories: 220 },
            { name: 'Ice Cream (1 scoop)', calories: 137 },
            { name: 'Coca Cola (1 can)', calories: 140 },
            { name: 'Beef Steak (grilled)', calories: 679 },
            { name: 'Fish (grilled)', calories: 232 },
            { name: 'Pancakes (3 medium)', calories: 227 },
            { name: 'Potato (boiled, 1 medium)', calories: 163 },
            { name: 'Mango', calories: 201 },
            { name: 'Avocado', calories: 234 },
            { name: 'Peach', calories: 59 },
            { name: 'Watermelon (1 slice)', calories: 30 },
            { name: 'Yogurt (plain, 1 cup)', calories: 100 },
            { name: 'Honey (1 tbsp)', calories: 64 },
            { name: 'Cereal (1 cup)', calories: 220 },
            { name: 'Bacon (3 slices)', calories: 150 },
            { name: 'Chicken Nuggets (6 pcs)', calories: 270 },
            { name: 'Sausage (1 link)', calories: 180 },
            { name: 'Porridge (1 cup)', calories: 150 },
            { name: 'Brown Bread (2 slices)', calories: 160 },
            { name: 'Butter (1 tbsp)', calories: 102 },
            { name: 'Cheese (1 slice)', calories: 113 },
            { name: 'Corn (1 cob)', calories: 123 },
            { name: 'Popcorn (1 cup)', calories: 55 },
            { name: 'Tuna (canned, 100g)', calories: 132 },
            { name: 'Oats (1 cup cooked)', calories: 154 },
            { name: 'Pineapple (1 cup)', calories: 82 },
            { name: 'Chips (1 bag, 28g)', calories: 160 },
            { name: 'Coffee (black)', calories: 2 },
            { name: 'Tea (without sugar)', calories: 2 },
            { name: 'Beer (1 bottle)', calories: 153 },
            { name: 'Wine (1 glass)', calories: 125 },
            { name: 'Pork Chop (grilled, 8oz)', calories: 272 },
            { name: 'Shrimp (100g)', calories: 99 },
            { name: 'Spaghetti (1 cup)', calories: 220 },
            { name: 'Lasagna (1 slice)', calories: 408 },
            { name: 'Sushi Roll (1 piece)', calories: 50 },
            { name: 'Turkey (roasted, 100g)', calories: 135 },
            { name: 'Broccoli (boiled)', calories: 55 },
            { name: 'Spinach (raw)', calories: 7 },
            { name: 'Cauliflower (boiled)', calories: 30 },
            { name: 'Lamb (100g)', calories: 294 },
            { name: 'Carrot (1 medium)', calories: 25 },
            { name: 'Tomato (1 medium)', calories: 22 },
            { name: 'Onion (1 medium)', calories: 44 },
            { name: 'Garlic (3 cloves)', calories: 13 },
            { name: 'Cucumber (1 medium)', calories: 45 },
            { name: 'Eggplant (grilled, 1 cup)', calories: 42 },
            { name: 'Mushroom (grilled, 1 cup)', calories: 35 },
            { name: 'Green Beans (boiled)', calories: 44 },
            { name: 'Peas (boiled, 1 cup)', calories: 125 },
            { name: 'Olive Oil (1 tbsp)', calories: 119 },
            { name: 'Quinoa (1 cup cooked)', calories: 222 },
            { name: 'Lentils (1 cup cooked)', calories: 230 },
            { name: 'Kidney Beans (1 cup cooked)', calories: 215 },
            { name: 'Tofu (100g)', calories: 144 },
            { name: 'Sweet Potato (1 medium)', calories: 112 },
            { name: 'Butter Chicken (1 cup)', calories: 490 },
            { name: 'Curry (vegetable, 1 cup)', calories: 175 },
            { name: 'Dal (1 cup cooked)', calories: 198 },
            { name: 'Paratha (1 medium)', calories: 270 },
            { name: 'Biryani (1 cup)', calories: 300 },
            { name: 'Samosa (1 medium)', calories: 130 },
            { name: 'Gulab Jamun (1 piece)', calories: 150 },
            { name: 'Dosa (1 medium)', calories: 120 },
            { name: 'Naan (1 piece)', calories: 140 },
            { name: 'Falafel (4 pieces)', calories: 180 }
        ];

        // Function to search and display calories for a food item
        function searchCalories() {
            const food = document.getElementById("food").value.toLowerCase();
            const result = foodData.find(item => item.name.toLowerCase() === food);
            const caloriesDisplay = document.getElementById("caloriesDisplay");

            if (result) {
                caloriesDisplay.textContent = `${result.name}: ${result.calories} kcal`;
            } else {
                caloriesDisplay.textContent = `Food item not found.`;
            }
        }

        // World Clock
        const cities = [
            { name: 'New York', timezone: 'America/New_York' },
            { name: 'London', timezone: 'Europe/London' },
            { name: 'Sydney', timezone: 'Australia/Sydney' },
            { name: 'Tokyo', timezone: 'Asia/Tokyo' },
            { name: 'Dubai', timezone: 'Asia/Dubai' }
        ];

        function updateWorldClock() {
            const clockDisplay = document.getElementById('worldClockDisplay');
            clockDisplay.innerHTML = '';

            cities.forEach(city => {
                const cityTime = new Date().toLocaleTimeString('en-US', {
                    timeZone: city.timezone,
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });

                const cityDiv = document.createElement('div');
                cityDiv.innerHTML = `<strong>${city.name}:</strong> ${cityTime}`;
                clockDisplay.appendChild(cityDiv);
            });
        }

        // Update world clock every second
        setInterval(updateWorldClock, 1000);
    </script>
</body>
</html>
